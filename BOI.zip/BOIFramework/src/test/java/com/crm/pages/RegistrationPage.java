package com.crm.pages;

import java.io.IOException;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.crm.base.TestBase;
import com.crm.listeners.CustomListener;
import com.crm.utilities.CommonMethods;
import com.crm.utilities.ExcelUtils;
import com.crm.utilities.ScreenShot;



public class RegistrationPage extends TestBase{
	public RegistrationPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}




	//PageMethods--starts

	//create Non digital complaint

	public void createNDComplaint(String complaintcreation_sheetname ) throws Exception {
		//Select CustomerTpe dropdown

		CommonMethods.selectByText("customerTypeDrpdownButton_XPATH",complaintcreation_sheetname,"CustomerType",1);


		CommonMethods.scrollDown(400);

		//		//Select customerType 
		//		CommonMethods.Click("customerTypeDrpdownButton_XPATH");
		//		String customerType=ExcelUtils.getCellData(complaintcreation_sheetname, "CustomerType", 1);
		//
		//		WebElement element = driver.findElement(By.xpath("//*[contains(text(),'" + customerType + "')]"));
		//		element.click();

		//Enter problemStatement

		CommonMethods.sendkeys("problemStatement_XPATH", complaintcreation_sheetname, "problemStatement", 1); 
		Thread.sleep(2000);
		CommonMethods.scrollDown(500);

		//Select Dealing Branch
		CommonMethods.Click("DealingBranchSearchIcon_XPATH");

CommonMethods.sendkeys("DealingBranchInputSearchTextBox_XPATH", complaintcreation_sheetname, "DealingBranch", 1);

	String DealingBranchName=ExcelUtils.getCellData(complaintcreation_sheetname, "DealingBranch", 1);

	CommonMethods.Click("DealingBranchInputSearchBoxArrowButton_XPATH");

	try {
			WebElement elementtext = driver.findElement(By.xpath("//*[contains(text(),'" + DealingBranchName + "')]"));
			Thread.sleep(2000);
			elementtext.click();
		}
	
		catch(StaleElementReferenceException e) {
			WebElement elementtext = driver.findElement(By.xpath("//*[contains(text(),'" + DealingBranchName + "')]"));
			Thread.sleep(2000);
			elementtext.click();
		}
		Thread.sleep(2000);

		//Select Category

		CommonMethods.Click("categorySearchIcon_XPATH");

		CommonMethods.sendkeys("CategoryInputSearchTextBox_XPATH", complaintcreation_sheetname, "Category", 1);

		String CategoryName=ExcelUtils.getCellData(complaintcreation_sheetname, "Category", 1);

		CommonMethods.Click("categoryInputSearchBoxArrowButton_XPATH");

		try {
			WebElement elementtext = driver.findElement(By.xpath("//div[contains(text(),'" + CategoryName + "')]"));
			Thread.sleep(2000);
			elementtext.click();
		}
		catch(StaleElementReferenceException e) {
			WebElement elementtext = driver.findElement(By.xpath("//div[contains(text(),'" + CategoryName + "')]"));
			Thread.sleep(2000);
			elementtext.click();
		}
		Thread.sleep(2000);



		//Select Sub Category

		CommonMethods.Click("SubCategorySearchIcon_XPATH");

		CommonMethods.sendkeys("SubCategoryInputSearchTextBox_XPATH", complaintcreation_sheetname, "SubCategory", 1);

		String SubCategoryName=ExcelUtils.getCellData(complaintcreation_sheetname, "SubCategory", 1);

		CommonMethods.Click("SubcategoryInputSearchBoxArrowButton_XPATH");

		try {
			WebElement elementtext = driver.findElement(By.xpath("//div[contains(text(),'" + SubCategoryName + "')]"));
			Thread.sleep(2000);
			elementtext.click();
		}
		catch(StaleElementReferenceException e) {
			WebElement elementtext = driver.findElement(By.xpath("//div[contains(text(),'" + SubCategoryName + "')]"));
			Thread.sleep(2000);
			elementtext.click();
		}
		Thread.sleep(2000);


		//Select sub Sub Category

		CommonMethods.Click("SubSubCategorySearchIcon_XPATH");

		CommonMethods.sendkeys("SubSubCategoryInputSearchTextBox_XPATH", complaintcreation_sheetname, "SubSubCategory", 1);

		String SubSubCategoryName=ExcelUtils.getCellData(complaintcreation_sheetname, "SubSubCategory", 1);

		CommonMethods.Click("SubSubcategoryInputSearchBoxArrowButton_XPATH");

		try {
			WebElement elementtext = driver.findElement(By.xpath("//div[contains(text(),'" + SubSubCategoryName + "')]"));
			Thread.sleep(2000);
			elementtext.click();
		}
		catch(StaleElementReferenceException e) {
			WebElement elementtext = driver.findElement(By.xpath("//div[contains(text(),'" + SubSubCategoryName + "')]"));
			Thread.sleep(2000);
			elementtext.click();
		}
		Thread.sleep(2000);

		//Enter value card number first 6 field
		CommonMethods.sendkeys("CardNumberFirst6_XPATH", complaintcreation_sheetname, "CardNumberFirst6", 1); 
		Thread.sleep(2000);

		//Enter value card number last 4 field
		CommonMethods.sendkeys("CardNumberFirst4_XPATH", complaintcreation_sheetname, "CardNumberLast4", 1); 
		Thread.sleep(2000);

		//Enter text in complaint remarks field

		CommonMethods.sendkeys("ComplaintRemarksTextBox_XPATH", complaintcreation_sheetname, "ComplaintRemarks", 1); 
		Thread.sleep(2000);


		// Click on save and proceed button
		CommonMethods.Click("ComplaintsaveandProceedButton_XPATH");


		Thread.sleep(20000);

		//click on ignore and create button

		CommonMethods.Click("IgnoreandCreate_XPATH");

		//get the complaint number and write in a excle sheet

		String ComplaintNumbertext= CommonMethods.getElementText("ComplaintNumber_XPATH");
		ExcelUtils.writeToExcel(complaintcreation_sheetname, 1, 10, ComplaintNumbertext);
		
		ScreenShot.takeScreenShot("NDComplaint Creation");


		//Select accountCardDetailSearchParatameter
		/*CommonMethods.selectByText("accountCardDetailSearchParatameterDropdown_XPATH",servicerequest_sheetname,"AccountCardDetailSearchParameter",1);


		CommonMethods.scrollDown(400);



		//Enter Function
		CommonMethods.sendkeys("function_XPATH", servicerequest_sheetname, "Function", 1);
		String Functiontext=ExcelUtils.getCellData(servicerequest_sheetname, "Function", 1);
		CommonMethods.PickerSelect(Functiontext);
		Thread.sleep(2000);

		//Enter SubFunction

		CommonMethods.sendkeys("subFunction_XPATH", servicerequest_sheetname, "SubFunction", 1);
		String SubFunctiontext=ExcelUtils.getCellData(servicerequest_sheetname, "SubFunction", 1);
		CommonMethods.PickerSelect(SubFunctiontext);
		Thread.sleep(2000);

		//Enter SubSubFunction

		CommonMethods.sendkeys("subsubFunction_XPATH", servicerequest_sheetname, "SubSubFunction", 1);
		String SubSubFunctiontext=ExcelUtils.getCellData(servicerequest_sheetname, "SubSubFunction", 1);
		CommonMethods.PickerSelect(SubSubFunctiontext);
		Thread.sleep(2000);

		//Select Nature of query
		CommonMethods.sendkeys("NatureOfQuery_XPATH", servicerequest_sheetname, "NatureofQuery", 1); 
		String NatureOfQueryText=ExcelUtils.getCellData(servicerequest_sheetname, "NatureofQuery", 1);
		CommonMethods.PickerSelect(NatureOfQueryText);
		Thread.sleep(2000);
		CommonMethods.scrollDown(200);

		//Enter Lodgement Remarks

		CommonMethods.sendkeys("remarkfield_XPATH", servicerequest_sheetname, "LodgementRemarks", 1); 
		Thread.sleep(2000); */



	} 


}
